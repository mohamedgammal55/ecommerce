
<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="Author" content="GeniusOcean">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> GeniusOcean - Script Updater</title>
	<!-- favicon -->
	<!-- bootstrap -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">

	<link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="installer-wrapper">
                <div class="installer-box">
                    <div class="heading-area">
                        <h4 class="title">
                                <i class="fas fa-cogs"></i> GeniusCart Updater
                        </h4>
                    </div>
                    <div class="text-center">
                    	<br><strong class="blink_me">You are ready to upgrade to GeniusCart Version 2.1!</strong> <br><br>
                                        </div>
                            <ul class="list-group">
                            <?php 
                                if(file_exists('../backup-index.zip')){
                                    echo '<li class="list-group-item you-can"><i class="far fa-check-circle"></i> Upgrade Index file.</li>';
                                }else{
                                    echo '<li class="list-group-item you-cant"><i class="far fa-times-circle"></i> Upgrade Index file.</li>
                                ';
                                }
                            
                            ?>
                            <?php 
                                if(file_exists('../backup-project.zip')){
                                    echo '<li class="list-group-item you-can"><i class="far fa-check-circle"></i> Upgrade Project files.</li>';
                                }else{
                                    echo '<li class="list-group-item you-cant"><i class="far fa-times-circle"></i> Upgrade Project files.</li>
                                ';
                                }
                            
                            ?>
 

                                <li class="list-group-item you-can"><strong class="">Please click on Update now and wait until the update it complete.</strong></li>
                               
                            </ul>
                    <div class="content">
<?php 
                                if(file_exists('../backup-index.zip') && file_exists('../backup-project.zip')){
?>
                        <form action="updater.php" method="POST" id="updater">
                            <div class="inner-box">
                                <div class="gocover" style="background: url(assets/css/hourglass.gif) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                                <div class="d-flex justify-content-center">
                                
                                    <button type="submit" id="submit-btn" class="mybtn1 text-center">Update Now</button>
                                </div>

                            </div>
                        </form>
                        <?php 
                                }else{

                                echo '<span style="color:red">Update file is missing! You can not upgrade to version 2.1 if your update file is missing. Please check and make sure that you have correct upgrade files.</span><br>';
                                }
                        
                        ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


	<!-- jquery -->
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
</body>

</html>