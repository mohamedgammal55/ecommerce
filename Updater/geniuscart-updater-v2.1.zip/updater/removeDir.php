<?php


// DELETE PROJECT FOLDER

rrmdir('../project/');

// DELETE PROJECT FOLDER ENDS

    //--- Zipping Section

    $zip_file = '../backup-project.zip';
    
    $zip = new \ZipArchive();  
    $res = $zip->open($zip_file);  
    $zip->extractTo('../');  
    $zip->close();  

    //--- Zipping Section

    // SET MARKURY

    mkdir('../project/vendor/markury');

    $zip = new \ZipArchive();  
    $res = $zip->open('../file-markury.zip');  
    $zip->extractTo('../project/vendor/markury');  
    $zip->close();  

    // SET MARKURY ENDS

    // SET UPDATE
    
    mkdir('../project/vendor/update');

    $zip = new \ZipArchive();  
    $res = $zip->open('../file-update.zip');  
    $zip->extractTo('../project/vendor/update');  
    $zip->close();  

    // SET UPDATE ENDS

//     //--- Zipping Section

    unlink("../index.php");
    $zip_file = '../backup-index.zip';
    
    $zip = new \ZipArchive();  
    $res = $zip->open($zip_file);  
    $zip->extractTo('../');  
    $zip->close();  

//     //--- Zipping Section

//     // REMOVE LISTS

unlink("../file-markury.zip");
unlink("../file-update.zip");

if (file_exists('../assets/front/css/styles.php')) {
    unlink('../assets/front/css/styles.php');
}

if (file_exists('../assets/front/css/all.css')) {
    unlink('../assets/front/css/all.css');
}

if (file_exists('../assets/admin/js/nicEdit.js')) {
    unlink('../assets/admin/js/nicEdit.js');
}

if (file_exists('../assets/admin/js/myscript.js')) {
    unlink('../assets/admin/js/myscript.js');
}
//     // REMOVE LISTS ENDS

// Replace Styles

$currentStylePath = '../styles.php';

$newStylePath = '../assets/front/css/styles.php';

rename($currentStylePath, $newStylePath);

// Replace Styles Ends


$currentAllPath = '../all.css';

$newAllPath = '../assets/front/css/all.css';

rename($currentAllPath, $newAllPath);

// Replace Styles Ends

copy('../nicEditIcons-latest.gif','../assets/images/nicEditIcons-latest.gif');



$currentNicPath = '../nicEdit.js';

$newNicPath = '../assets/admin/js/nicEdit.js';

rename($currentNicPath, $newNicPath);

// Replace Styles Ends


// Replace Scripts

$currentJsPath = '../myscript.js';

$newJsPath = '../assets/admin/js/myscript.js';

rename($currentJsPath, $newJsPath);

// Replace Scripts Ends


    function rrmdir($pdir) {
        if (is_dir($pdir)) {
        $objects = scandir($pdir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
            if (filetype($pdir."/".$object) == "dir") 
                rrmdir($pdir."/".$object); 
            else unlink ($pdir."/".$object);
            }
        }
        reset($objects);
        rmdir($pdir);
        }
    }

	$base_url = home_base_url();
	if (substr($base_url, -1 == "/")) {
		$base_url = rtrim($base_url,"/");
	}
	
	function home_base_url(){   
	  $base_url = (isset($_SERVER['HTTPS']) &&
	  $_SERVER['HTTPS']!='off') ? 'https://' : 'http://';
	  $tmpURL = dirname(__FILE__);
	  $tmpURL = str_replace(chr(92),'/',$tmpURL);
	  $tmpURL = str_replace($_SERVER['DOCUMENT_ROOT'],'',$tmpURL);
	  $tmpURL = ltrim($tmpURL,'/');
	  $tmpURL = rtrim($tmpURL, '/');
	  $tmpURL = str_replace('install','',$tmpURL);
	  $base_url .= $_SERVER['HTTP_HOST'].'/'.$tmpURL;
	  return $base_url; 
	}

    $redirect_url = str_replace('/updater','',$base_url.'/update-finalize');

    header('Location: '.$redirect_url);

?>