<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Api_notification extends Model{

    protected $guarded=[];

    protected $table='api_notification';

}//end class
