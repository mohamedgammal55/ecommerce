<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopSlider extends Model{
    protected $table = 'top_slider';
    protected $guarded=[];
}
